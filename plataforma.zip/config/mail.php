<?php return array (
  'driver' => 'mail',
  'host' => 'localhost',
  'port' => '25',
  'from' => 
  array (
    'address' => 'infoplataformavsystem@gmail.com',
    'name' => 'virtual',
  ),
  //'encryption' => 'ssl',
  //'username' => 'infoplataformavsystem@gmail.com',
  //'password' => 'app12345$',
  //'sendmail' => '/usr/sbin/sendmail -bs',
  'pretend' => false,
);