<?php return array (
  'mailgun' => 
  array (
    'domain' => '',
    'secret' => '',
  ),
  'mandrill' => 
  array (
    'secret' => '',
  ),
  'ses' => 
  array (
    'key' => '',
    'secret' => '',
    'region' => 'us-east-1',
  ),
  'stripe' => 
  array (
    'model' => '',
    'key' => '',
    'secret' => '',
  ),
  'facebook' => 
  array (
    'client_id' => '',
    'client_secret' => '',
    'redirect' => '',
  ),
  'github' => 
  array (
    'client_id' => '',
    'client_secret' => '',
    'redirect' => '',
  ),
);