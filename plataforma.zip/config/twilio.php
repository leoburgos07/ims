<?php return array (
  'sid' => '',
  'token' => '',
  'from' => '',
);