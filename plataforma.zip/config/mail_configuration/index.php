<?php return array (
  'driver' => 'mail',
  'host' => 'smtp.gmail.com',
  'port' => '465',
  'from' => 
  array (
    'address' => 'infoplataformavsystem@gmail.com',
    'name' => 'Sistema de Comisiones',
  ),
  'encryption' => 'tls',
  'username' => '',
  'password' => '',
  'sendmail' => '/usr/sbin/sendmail -bs',
  'pretend' => false,
);