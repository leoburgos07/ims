<?php
return [
    'MODE' => '1',
    'DISABLE_MESSAGE' => 'This feature is not available in demo mode.',
    'UPDATED' => 'Updated Successfully.',
    'ADDED' => 'Added Successfully.',
    'DELETED' => 'Deleted Successfully.',
    'INVALID_LINK' => 'This is not a valid link.',
    'SAVED' => 'Saved Successfully.',
    'NA' => 'You dont have permission to perform this action.',
    'CSRF' => 'Invalid CSRF Token.',
    'VERSION' => '1.0'
];