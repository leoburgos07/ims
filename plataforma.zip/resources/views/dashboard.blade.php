@extends('layouts.default')

	@section('content')
	<div class="row">
		<div class="col-sm-9">
			<div class="box-info">
				<div id="calendar"></div>
			</div>
		</div>
		
		
	</div>
	@stop