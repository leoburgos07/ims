@extends('layouts.default')

	@section('content')
		<div class="row">
			<div class="col-sm-12">
				<div class="box-info">
					<h2><strong>{!! trans('messages.Edit') !!} </strong> {!! trans('Usuario') !!}</h2>
					{!! showMessage() !!}
					{!! Form::model($user,['method' => 'PATCH','route' => ['user.update',$user->id] ,'class' => 'user-form']) !!}
						  <div class="form-group">
						    <!--{!! Form::label('name_invited',trans('Me invito'),[])!!}-->
							{!! Form::input('hidden','name_invited',isset($user->name_invited) ? $user->name_invited : '',['class'=>'form-control','placeholder'=>''])!!}
						  </div>
						  <div class="form-group">
						    {!! Form::label('name',trans('Nombre'),[])!!}
							{!! Form::input('text','name',isset($user->name) ? $user->name : '',['class'=>'form-control','placeholder'=>'Ingrese su nombre'])!!}
						  </div>	
						  <div class="form-group">
						    {!! Form::label('role_id',trans('messages.Role'),[])!!}
							{!! Form::select('role_id', [''=>''] + $roles, isset($role_id) ? $role_id : '',['class'=>'form-control input-xlarge select2me','placeholder'=>'Seleccione Rol'])!!}
						  </div>
						  <div class="form-group">
						    {!! Form::label('email',trans('messages.Email'),[])!!}
							{!! Form::input('text','email',isset($user->email) ? $user->email : '',['class'=>'form-control','placeholder'=>'Ingrese Email'])!!}
						  </div>
			  			  {{ App\Classes\Helper::getCustomFields('user-form',$custom_field_values) }}
						  <div class="col-sm-10">
						  	{!! Form::submit(isset($buttonText) ? $buttonText : trans('Guardar'),['class' => 'btn btn-primary']) !!}
						  	{!! Form::close() !!}
						  </div>
						  <br />
						  <br />
						  <br />
						  <?php
						  	
						  	if($user->confirm_pay_code == 0){
						  		echo "<form action='../generatepaycode/".$user->id." method='GET'>";
						  		echo "<div class='form-group'>";
						  		echo "<strong>Tipo de Invitado</strong> <br><br>";
						  		echo "<input type='radio' name='paquete' value='uno' checked> Invitado 1 (USD 10)<br><br>";
						  		echo "<input type='radio' name='paquete' value='cinco' > Invitado 2 (USD 10)<br><br>";
						  		echo "<input type='radio' name='paquete' value='diez' > Invitado 3 (USD 30)<br><br>";
						  		echo "</div>";
						  		echo "<div class='form-group'>";
						  		echo "<input type = 'submit' value = 'Generar Codigo' class='btn btn-primary'>";
						  		echo "</div>";
						  		echo "</form>";
						  	}
						  	
						  	?>
					
				</div>
			</div>
		</div>

	@stop