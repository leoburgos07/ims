			<!-- BEGIN CONTENT HEADER -->
            <div class="header content rows-content-header">
			
				<!-- Button mobile view to collapse sidebar menu -->
				<button class="button-menu-mobile show-sidebar">
					<i class="fa fa-bars"></i>
				</button>
				
				<!-- BEGIN NAVBAR CONTENT-->				
				<div class="navbar navbar-default flip" role="navigation">
					<div class="container">
						<!-- Navbar header -->
						<div class="navbar-header">
						<div class="row">
							<div class="col-md-8">
								<img src="http://plataforma.virtualsystem.co/um2/um2/public/assets\images\logovapp.png" class="img-rounded" style="alt:70px; width:125px; margin-left:63px;">
							</div>
						</div>
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<i class="fa fa-angle-double-down"></i>
							</button>
							<!--@if (in_array('hide_sidebar',$assets))
							<a href="/" class="navbar-brand" style="margin-left:5px;"><i class="fa fa-sign-in fa-2x logo-icon"></i> <strong>{!! config('config.application_name') !!}</strong></a>
							@endif-->
						</div><!-- End div .navbar-header -->
						
						<!-- Navbar collapse -->	
						<div class="navbar-collapse collapse">
							<!-- Left navbar -->
							@if (in_array('hide_sidebar',$assets))
							<ul class="nav navbar-nav">
								@if(Auth::check() && !Entrust::hasRole('user'))
								<li><a href="/dashboard">Tablero</a></li>
								@endif
							</ul>
							@endif
							
							<!-- Right navbar -->
							<ul class="nav navbar-nav navbar-right top-navbar">

								<!--@if(config('config.facebook_page_link'))
									<li><a href="{!! URL::to(config('config.facebook_page_link')) !!}" data-toggle="tooltip" title="Facebook" target=_blank><i class="fa fa-facebook-official fa-lg " style="color:#3b5998;"></i></a></li>
								@endif
								@if(config('config.twitter_page_link'))
									<li><a href="{!! URL::to(config('config.twitter_page_link')) !!}" data-toggle="tooltip" title="Twitter" target=_blank><i class="fa fa-twitter-square fa-lg " style="color:#00aced;"></i></a></li>
								@endif-->


							@if (Auth::check())
								@if(!Entrust::hasRole('user'))

								<li>
									<a href="./todo" data-toggle='modal' data-target='#myTodoModal' ><i class="fa fa-list-ul"></i> Agregar evento</a>
								</li>
								<!--<li class="dropdown">
									<a href="#fakelink" class="dropdown-toggle" data-toggle="dropdown">Lang ({!! config('config.default_language') !!}) <i class="fa fa-chevron-down i-xs"></i></a>
									<ul class="dropdown-menu animated half flipInX">
										@if(Entrust::can('set_language'))
										@foreach($languages as $key => $language)
										<li><a href="{!! URL::to('/setLanguage/'.$key) !!}">{!! $language." (".$key.")" !!}</a></li>
										@endforeach
										@endif
										@if(Entrust::can('manage_language'))
										<li><a href="/language">Add More Language</a></li>
										@endif
									</ul>
								</li>-->

								@endif

								<!--@if(Entrust::can('manage_message'))
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i>
										{!! ($header_inbox_count) ? '<span class="label label-danger absolute">'.$header_inbox_count.'</span>' : '' !!}
									</a>
									<ul class="dropdown-menu dropdown-message animated half flipInX">
										@if(!$header_inbox_count)
										<li class="dropdown-header notif-header">
											No unread message
										</li>
										@endif
										@foreach($header_inbox as $inbox)
										<li class="dropdown-header notif-header">Nuevos mensajes</li>
										<li class="divider"></li>
										<li class="unread">
											<a href="{!! URL::to('/message/view/'.$inbox->id.'/'.$token) !!}">
												{!! App\Classes\Helper::getAvatar($inbox->user_id) !!}
												<span style="margin-left:10px;font-weight:bold;">{!! $inbox->name !!}</span><br />
												<span style="margin-left:10px;font-size:11px;color:green;"><i>{!! \App\Classes\Helper::showDateTime($inbox->time) !!}</i></span><br />
												<span style="margin-left:10px;">{!! $inbox->subject !!}</span>
											</a>
										</li>
										@endforeach

										@if($header_inbox_count > count($header_inbox))
										<li class="dropdown-footer">
											<a href="/message">
												<i class="fa fa-share"></i> vert todos los mensajes
											</a>
										</li>
										@endif
									</ul>
								</li>
								@endif-->

								<!-- Dropdown User session -->
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">Bienvenido, <strong>{!! Auth::user()->name !!}</strong> <i class="fa fa-chevron-down i-xs"></i></a>
									<ul class="dropdown-menu animated half flipInX">
										@if(isset(Auth::user()->username))
											<li><a href="{!! URL::to('/change_password') !!}">Cambiar la contraseña</a></li>
										@endif
										<li><a href="{!! URL::to('/logout') !!}">Cerrar sesión</a></li>
									</ul>
								</li>
							@endif
								
								<!-- End Dropdown User session -->
							</ul>
						</div><!-- End div .navbar-collapse -->
					</div><!-- End div .container -->
				</div>
				<!-- END NAVBAR CONTENT-->
            </div>
			<!-- END CONTENT HEADER -->
				