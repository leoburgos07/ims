		<!-- BEGIN SIDEBAR -->
		<div class="left side-menu">
			
			
            <div class="body rows scroll-y">
				
				<!-- Scrolling sidebar -->
                <div class="sidebar-inner slimscroller">
				
				@include('auth.user_detail',['user' => Auth::user(),'edit_profile' => 1, 'role' => 1,'welcome' => '1', 'logout' => '1', 'last_login' => '0'])

				@if(config('constants.MODE') == 0)
					<center><a href="http://codecanyon.net/item/x/13760351?ref=wmlabs" class="btn btn-success btn-md" role="button">Buy Now</a></center>
				@endif
					<!-- Sidebar menu -->				
					<div id="sidebar-menu">
						
						<ul>
							<li><a href="{!! URL::to('./dashboard') !!}"><i class="fa fa-home icon"></i> {!! trans('Tablero de Instrumentos') !!}</a></li>
							<li><a href="{!! URL::to('/arbol') !!}"><i class="fa fa-sitemap"></i> {!! trans('Consultar mi Arbol') !!} </a></li>
							<li><a href=""><i class="fa fa-users icon"></i><i class="fa fa-angle-double-down i-right"></i> {!! trans('Clientes') !!}</a>
							<ul>
							<li><a href="{!! URL::to('/cliente') !!}"><i class="fa fa-user-plus"></i> {!! trans('Crear Cliente ') !!} </a></li>
							<li><a href="{!! URL::to('/ventaC') !!}"><i class="fa fa-user"></i> {!! trans(' Listar Clientes') !!} </a></li>
							</ul>
							@if(Entrust::can('manage_user'))
								<li><a href=""><i class="fa fa-users icon"></i><i class="fa fa-angle-double-down i-right"></i> {!! trans('Usuarios') !!}</a>
							
								<ul>

									<li><a href="http://plataforma.virtualsystem.co/um2/um2/public/user"><i class="fa fa-angle-right"></i> {!! trans('Listar Usuarios') !!}</a></li>
									<!--
									@if(Entrust::can('create_user'))
									<li><a href="{!! URL::to('/user/create') !!}"><i class="fa fa-angle-right"></i> {!! trans('Agregar nuevo') !!} </a></li>
									@endif
									<li><a href="http://plataforma.virtualsystem.co/um2/um2/public/user"><i class="fa fa-angle-right"></i> {!! trans('messages.List All Users') !!}</a></li>
									@foreach(\App\Role::get() as $role)
									<li><a href="{!! URL::to('./user/list/'.$role->name) !!}"><i class="fa fa-angle-right"></i> List {!! $role->display_name !!} </a></li>
									@endforeach
									-->
								</ul>
							</li>
							
							@endif
							@if(Entrust::hasRole('admin'))
								<li><a href="{!! URL::to('./configuration') !!}"><i class="fa fa-cogs icon"></i> {!! trans('Configuración') !!}</a></li>
								<li><a href="{!! URL::to('./custom_field') !!}"><i class="fa fa-clone icon"></i> {!! trans('Campos Personalizados') !!}</a></li>
								<li><a href="{!! URL::to('./template') !!}"><i class="fa fa-envelope icon"></i> {!! trans('Plantillas de Correo') !!}</a></li>
								<li><a href="{!! URL::to('./sms_template') !!}"><i class="fa fa-mobile icon"></i> {!! trans('Plantillas de SMS') !!}</a></li>
							@endif
							@if(Entrust::can('manage_message'))
								<li><a href="{!! URL::to('./message') !!}"><i class="fa fa-envelope icon"></i> {!! trans('Mensajes') !!}</a></li>
							@endif
						</ul>
						<div class="clear"></div>
					</div><!-- End div #sidebar-menu -->
				</div><!-- End div .sidebar-inner .slimscroller -->
            </div><!-- End div .body .rows .scroll-y -->
			
			<!-- Sidebar footer -->
            <div class="footer rows animated fadeInUpBig">
				<div class="logo-brand header sidebar rows">
					<div class="logo">
						<h1><a href="{!! URL::to('/') !!}"><i class="fa fa-sign-in fa-2x logo-icon" ></i> {!! config('config.application_name').' '.config('constants.VERSION') !!}</a> </h1>
						<button class="sidebar-toggle">palanca</button>
					</div>
				</div>
            </div><!-- End div .footer .rows -->
        </div>
		<!-- END SIDEBAR -->