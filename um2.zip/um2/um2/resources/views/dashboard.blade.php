@extends('layouts.default')

	@section('content')
	<div class="row">
		<div class="col-sm-6">
			<div class="box-info">
				<div id="calendar"></div>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="box-info">
				<h2><strong>{!! trans('Actividad') !!}</strong> {!! trans('Reciente') !!}</h2>
				<div class="scroll-widget">
					<ul class="media-list">
					@foreach($activities as $activity)
					  <li class="media">
						<a class="pull-{!! App\Classes\Helper::activityShow() !!}" href="#fakelink">
						  {!! App\Classes\Helper::getAvatar($activity->user_id) !!}
						</a>
						<div class="media-body {!! App\Classes\Helper::activityColorShow() !!}">
						  <strong>@if(Auth::user()->id == $activity->user_id) Me @else {!! $activity->name !!} @endif</strong><br />
						  {!! $activity->text !!}
						  <p class="time">{!! App\Classes\Helper::showDateTime($activity->created_at) !!}</p>
						</div>
					  </li>
					@endforeach
					</ul>
				</div>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="box-info">
				<h2><strong>{!! trans('Mensaje') !!}</strong> {!! trans('Rapido') !!}</h2>
				<div class="additional-btn">
					  <a class="additional-icon" id="dropdownMenu5" data-toggle="dropdown">
						<i class="fa fa-cog"></i>
					  </a>
					  <ul class="dropdown-menu pull-right flip animated half fadeInDown" role="menu" aria-labelledby="dropdownMenu5">
						<li role="presentation"><a role="menuitem" tabindex="-1" href="/message/compose">{!! trans('Crear') !!}</a></li>
						<li role="presentation"><a role="menuitem" tabindex="-1" href="/message">{!! trans('Bandeja de entrada') !!}</a></li>
						<li role="presentation"><a role="menuitem" tabindex="-1" href="/message/sent">{!! trans('Enviados') !!}</a></li>
					  </ul>
					  <a class="additional-icon" href="#" data-toggle="collapse" data-target="#quick-post"><i class="fa fa-chevron-down"></i></a>
				</div>
				
				<div id="quick-post" class="collapse in">
					{!! Form::open(['route' => 'message.store','role' => 'form', 'class'=>'compose-form']) !!}
						<div class="form-group">
							{!! Form::select('to_user_id', [null=>'Seleccione'] + $user_list, '',['class'=>'form-control input-xlarge select2me','placeholder'=>'Seleccione personal'])!!}
						</div>
						<div class="form-group">
							{!! Form::input('text','subject','',['class'=>'form-control','placeholder'=>'Asunto del mensaje'])!!}
						</div>
						<div class="form-group">
							{!! Form::textarea('content','',['class' => 'form-control summernote-small', 'placeholder' => 'Introduzca Descripción'])!!}
						</div>
						<div class="row">
							<div class="col-md-6">
								<button type="submit" class="btn btn-sm btn-success">{!! trans('Enviar') !!}</button>
							</div>
						</div>
					{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
	@stop