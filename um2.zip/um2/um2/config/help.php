<?php
return array(
	'department_index' => 'In this page, you can list of all the departments you have added.
		To edit name/description of any department, you can click on edit icon & to delete any department
		you can click on delete icon. Remember, when you click on delete button, it will ask for confirmation. It will be
		deleted only when no other data will be linked to this entity.',
	'designation_index' => 'In this page, you can list of all the designations you have added.
		To edit name/department of any designation, you can click on edit icon & to delete any department
		you can click on delete icon. Remember, when you click on delete button, it will ask for confirmation. It will be
		deleted only when no other data will be linked to this entity.'
	);