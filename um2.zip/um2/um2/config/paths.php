<?php
return [
    'COUNTRY_PATH' => '/config/country.php',
    'TIMEZONE_PATH' => '/config/timezone.php',
    'LANGUAGE_PATH' => '/config/language.php',
    'LANG_PATH' => '/config/lang.php',
    'CONFIG_PATH' => '/config/config.php',
    'MAIL_PATH' => '/config/mail.php',
    'SMS_PATH' => '/config/twilio.php',
    'TEMPLATE_PATH' => '/config/template.php',
    'SERVICE_PATH' => '/config/services.php',
    'SMS_TEMPLATE_PATH' => '/config/sms_template.php',
    'PAGE_PATH' => '/config/page.php',
];