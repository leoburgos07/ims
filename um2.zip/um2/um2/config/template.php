<?php return array (
  'forgot_password' => 
  array (
    'title' => 'Laravel User Management | Forgot Passwords',
    'fields' => 'NAME,USERNAME,EMAIL,LINK',
  ),
  'activation_mail' => 
  array (
    'title' => 'Laravel User Management | Activation Mails',
    'fields' => 'USERNAME,EMAIL,LINK',
  ),
  'welcome_mail' => 
  array (
    'title' => 'Laravel User Management | Welcome',
    'fields' => 'NAME,USERNAME,EMAIL',
  ),
);