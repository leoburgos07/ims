<?php return array (
  'en' => 'English',
  'es' => 'Español',
);