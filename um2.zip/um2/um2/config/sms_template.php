<?php return array (
  'welcome_sms' => 
  array (
    'fields' => 'NAME,USERNAME,EMAIL',
  ),
);