<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use DB;
use Input;

class ValidatePayCode extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('auth/validate_code');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function generate($id, Request $request)
    {
        DB::table('users')
            ->where('id', $id)
            ->update(['pay_code' => str_random(10)]);
            
        $paquete= $request->input('paquete');
        $users = DB::select('select * from users where id = :id', ['id'=>$id] );
        
        foreach($users as $user){
		mail($user->email, "Codigo de Activacion", "Su codigo de activacion es ".$user->pay_code);
		$name_invited = $user->name_invited;
		$username = $user->username;
	}
	
	$this->comision($username, $name_invited, $paquete);
	 
	return redirect('http://plataforma.virtualsystem.co/um2/um2/public/user');				
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function save($id, Request $request)
    {
        $users = DB::select('select * from users where id = :id', ['id'=>$id] );
        $codigo= $request->input('codigo');
        foreach($users as $user){
        	if ($user->pay_code == $codigo){
        	
        		DB::table('users')
		            ->where('id', $id)
		            ->update(['confirm_pay_code' => 1]);
		        return redirect('http://plataforma.virtualsystem.co/um2/um2/public');
        		
        	}else{
        		
        		return redirect()->back()->withErrors('Codigo no valido');
        		
        	}
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    private function comision($username, $name_invited, $paquete)
    {	
    
    	$drop1 = DB::statement("DROP TABLE IF EXISTS comision1");
    	$drop2 = DB::statement("DROP TABLE IF EXISTS comision2");
 	$comision1 = DB::statement("CREATE TABLE comision1 SELECT id, username, name_invited, created_at FROM users WHERE name_invited = '$name_invited' ORDER BY created_at LIMIT 0,3");
        $comision2 = DB::statement("CREATE TABLE comision2 SELECT id, username, name_invited, created_at FROM users WHERE name_invited = '$name_invited' ORDER BY created_at");
        $delete = DB::statement("DELETE FROM comision2 WHERE id in ( SELECT * FROM (SELECT id FROM comision1) as ti)");
        $comisiones = DB::select("SELECT * FROM comision1 WHERE username = '$username'");
        
        
        if ($comisiones != null)
        {
            if ($paquete == 'uno'){

            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 10 );
            
            }   
            if ($paquete == 'cinco'){
            
            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 10 );
            
            } 
            if ($paquete == 'diez'){
            
            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 30 );
            
            }
        }
        else{
        
        	$commisions = DB::select("SELECT * FROM users WHERE username = '$name_invited'");
        	foreach($commisions as $user)
        	{
        		if ($user->name_invited != 'nada'){
        			$this->consultas($user->name_invited, $user->username, $paquete);
        		}
        	}
        
        }
    }
    private function consultas ($name_invited, $username, $paquete)
    {
    	$drop1 = DB::statement("DROP TABLE IF EXISTS comision1");
    	$drop2 = DB::statement("DROP TABLE IF EXISTS comision2");
 	$comision1 = DB::statement("CREATE TABLE comision1 SELECT id, username, name_invited, created_at FROM users WHERE name_invited = '$name_invited' ORDER BY created_at LIMIT 0,2");
        $comision2 = DB::statement("CREATE TABLE comision2 SELECT id, username, name_invited, created_at FROM users WHERE name_invited = '$name_invited' ORDER BY created_at");
        $delete = DB::statement("DELETE FROM comision2 WHERE id in ( SELECT * FROM (SELECT id FROM comision1) as ti)");
        $comisiones = DB::select("SELECT * FROM comision2 WHERE username = '$username'");
        
        if ($comisiones != null)
        {
            if ($paquete == 'uno'){

            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 10 );
            
            }   
            if ($paquete == 'cinco'){
            
            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 10 );
            
            } 
            if ($paquete == 'diez'){
            
            DB::table('users')
                ->where('username', $name_invited)
                ->increment('comision', 30 );
            
            }
        }
        else{
        
        	$commisions = DB::select("SELECT * FROM users WHERE username = '$name_invited'");
        	foreach($commisions as $user)
        	{
        	
        		if ($user->name_invited != 'nada'){
        			$this->consultas($user->name_invited, $user->username, $paquete);
        		}
        	
        	}
        
        }
        
    }
}