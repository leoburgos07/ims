<?php

namespace App\Http\Controllers\Auth;
use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use App\Role;
use App\Department;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\UserRegisterRequest;
use Entrust;
use App\Profile;
use App\Classes\Helper;
use Auth;
use DB;
use Config;
use Mail;
use File;
use Activity;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => ['getLogout','getRegister','postRegister']]);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            
            'name_invited' => 'required|max:255|exists:users,username',
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
            'telefono' => 'required|digits:11',
            
            
        ]);
    }
 /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name_invited' => $data['name_invited'],
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'telefono' => $data['telefono'],
        ]);
    }

    public function getUserRegister(){
  ;
        return view('auth.register');
    }

    public function getRegister()
    {
        if(!Entrust::can('create_user'))
            return redirect('/dashboard')->withErrors(config('constants.NA'));

        if(Entrust::hasRole('admin'))
            $roles = Role::lists('name','id')->all();
        else
            $roles = Role::where('name','!=','admin')->lists('name','id')->all();

        return view('user.create',compact('roles'));
    }

    public function postRegister(RegisterRequest $request, User $user){
        
        if(!Entrust::can('create_user'))
            return redirect('/dashboard')->withErrors(config('constants.NA'));

        $user->fill($request->all());
        $user->password = bcrypt($request->input('password'));

        $key = config('app.key');
        $user->confirmation_code = hash_hmac('sha256', str_random(40), $key);
        $user->confirmed = 1;
        $user->save();

        $profile = new Profile;
        $profile->user()->associate($user);
        $profile->save();
        $user->attachRole($request->input('role_id'));

        $activity = Auth::user()->name.' Crear un usuario ('.$user->name.')';
        Activity::log($activity);
        return redirect()->back()->withSuccess('Usuario creado con exito. ');
    }

    public function postUserRegister(UserRegisterRequest $request, User $user){
        
        $user->fill($request->all());
        $user->password = bcrypt($request->input('password'));

        $key = config('app.key');
        $confirmation_code = hash_hmac('sha256', str_random(40), $key);
        $user->confirmation_code = $confirmation_code;
        $user->save();

        $filename = base_path().'/config/template/'.DOMAIN.'/activation_mail';
        $content = File::get($filename);
        $base_url = url('/');
        $link = $base_url.'/activate/'.$confirmation_code;

        $content = str_replace('[LINK]',$link,$content);
        $content = str_replace('[EMAIL]',$user->email,$content);
        $content = str_replace('[USERNAME]',$user->username,$content);
        
	mail($user->email, "Correo de Activacion", $content);
        //Mail::send('template.mail', compact('content'), function($message) use ($user){
        //    $message->to($user->email)->subject('Activate your account');
        //});

        $profile = new Profile;
        $profile->user()->associate($user);
        $profile->save();

        $role = Role::where('name','=','user')->first();
        if($role)
        $user->attachRole($role->id);
        
        return redirect()->back()->withSuccess('Usuario registrado Correctamente.');
    }

    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }
    
    public function handleProviderCallback($provider)
    {

        $user_detail = Socialite::driver($provider)->user();

        $data = [
            'email' => $user_detail->getEmail()
        ];

        Auth::login(User::firstOrCreate($data));

        $user = Auth::user();
        $user->name = ($user->name) ? : $user_detail->getName();
        $user->username = ($user->username) ? : null;
        $user->confirmed = 1;
        $user->provider = $provider;
        $user->save();

        $profile = $user->Profile ?: new Profile;
        $profile->user()->associate($user);
        $profile->save();

        if(!count($user->roles)){
            $role = Role::where('name','=','user')->first();
            if($role)
            $user->attachRole($role->id);
        }

        return redirect($this->redirectPath());
    }
    
    protected $username = 'username';
    protected $redirectPath = '/';
    protected $loginPath = '/';
}